Buttons
=======

An example that demonstrates how to capture input from the buttons.
