#ifndef BREAKOUT_BITMAPS_H
#define BREAKOUT_BITMAPS_H

#include <avr/pgmspace.h>

extern const unsigned char fire[];
extern const unsigned char title[];
extern const unsigned char arrow[];

#endif